import React from 'react';
import NavbarMobile from '../../components/layout/NavbarMobile';
import SectionMobile from '../mobile/SectionMobile';
import NavbarBottom from '../mobile/NavbarBottom';


const LandingPageMobile = () => {
  return (
    <div className="min-h-screen overflow-y-auto bg-[#fff8c0]">


      <NavbarMobile/>
      <SectionMobile />
     
      <NavbarBottom/>
    </div>
  );
};

export default LandingPageMobile;
