import Img1 from "../assets/images/landing page/section2-images/category-section-section2/1.png"
import Img2 from "../assets/images/landing page/section2-images/category-section-section2/2.png"
import Img3 from "../assets/images/landing page/section2-images/category-section-section2/3.png"
import Img4 from "../assets/images/landing page/section2-images/category-section-section2/4.png"
import Img5 from "../assets/images/landing page/section2-images/category-section-section2/5.png"
import Img6 from "../assets/images/landing page/section2-images/category-section-section2/6.png"
import Img7 from "../assets/images/landing page/section2-images/category-section-section2/7.png"

const sectionsData = [
    { title: 'Dairy', src: Img1 },
    { title: 'Snacks', src: Img2 },
    { title: 'Fast food', src: Img3 },
    { title: 'Makeup', src: Img4 },
    { title: 'Frozen', src: Img5 },
    { title: 'Cleaning', src: Img6 },
    { title: 'Bakery', src: Img7 },
    { title: 'Dairy', src: Img1 },
    { title: 'Snacks', src: Img2 },
    { title: 'Fast food', src: Img3 },
    { title: 'Makeup', src: Img4 },
    { title: 'Frozen', src: Img5 },
    { title: 'Cleaning', src: Img6 },
    { title: 'Bakery', src: Img7 },
    { title: 'Dairy', src: Img1 },
    { title: 'Snacks', src: Img2 },
    { title: 'Fast food', src: Img3 },
    { title: 'Makeup', src: Img4 },
    { title: 'Frozen', src: Img5 },
    { title: 'Cleaning', src: Img6 },
    { title: 'Bakery', src: Img7 },
  ];
  
  export default sectionsData;
  