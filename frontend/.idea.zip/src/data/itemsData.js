import image1 from "../assets/images/landing page/section2-images/im1.jpg"
const itemsData = [
    { title: 'Item 1', price: '7.99', imageSrc: image1 },
    { title: 'Item 2', price: '5.99', imageSrc: image1 },
    { title: 'Item 3', price: '3.99', imageSrc: image1 },
    { title: 'Item 4', price: '9.99', imageSrc: image1 },
    { title: 'Item 5', price: '6.99', imageSrc: image1 },
    { title: 'Item 6', price: '4.99', imageSrc: image1 },
  ];
  
  export default itemsData;
  