package com.example.ShopiShop.dto.request;

import lombok.Data;

@Data
public class SectionRequestDTO {
    private String name;
    private String imageUrl;
}
