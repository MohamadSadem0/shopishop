package com.example.ShopiShop.enums;

public enum OrderStatusEnum {
    PENDING, COMPLETED, CANCELLED
}
