package com.example.ShopiShop.services;

public interface NotificationService {
}
