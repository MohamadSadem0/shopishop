package com.example.ShopiShop.enums;

public enum PaymentMethodEnum {
    CREDIT_CARD, PAYPAL
}
