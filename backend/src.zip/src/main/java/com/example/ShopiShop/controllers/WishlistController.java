package com.example.ShopiShop.controllers;

public class WishlistController {
}
