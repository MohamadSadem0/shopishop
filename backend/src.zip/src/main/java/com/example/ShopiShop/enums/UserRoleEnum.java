package com.example.ShopiShop.enums;

public enum UserRoleEnum {
    SUPERADMIN,
    MERCHANT,
    CUSTOMER,

}
