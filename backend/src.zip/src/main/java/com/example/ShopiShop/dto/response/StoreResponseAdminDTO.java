package com.example.ShopiShop.dto.response;

public class StoreResponseAdminDTO {
}
