package com.example.ShopiShop.enums;

public enum PaymentStatusEnum {
    SUCCESS, FAILED
}
