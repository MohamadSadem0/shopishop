package com.example.ShopiShop.exceptions;

public class StoreNotFoundException {
}
