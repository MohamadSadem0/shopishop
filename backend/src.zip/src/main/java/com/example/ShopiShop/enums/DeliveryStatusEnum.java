package com.example.ShopiShop.enums;

public enum DeliveryStatusEnum {
    SUCCESS, FAILED
}
