package com.example.ShopiShop.repositories;

public class WishlistRepository {
}
