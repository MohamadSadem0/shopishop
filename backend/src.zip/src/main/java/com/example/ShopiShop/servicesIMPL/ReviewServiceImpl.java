package com.example.ShopiShop.servicesIMPL;

public class ReviewServiceImpl {
}
