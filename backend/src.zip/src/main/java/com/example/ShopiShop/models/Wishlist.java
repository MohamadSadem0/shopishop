package com.example.ShopiShop.models;

public class Wishlist {
}
//. WishlistItem
//Attributes:
//id: Long
//user: User (Many-to-One)
//product: Product (Many-to-One)